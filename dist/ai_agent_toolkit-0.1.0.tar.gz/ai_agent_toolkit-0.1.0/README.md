# 🤖 AI Agent Framework

> A lightweight, extensible framework for building AI agents with tools, memory, and multi-step reasoning.

[![Python](https://img.shields.io/badge/Python-3.10+-blue)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-green)](LICENSE)
[![Version](https://img.shields.io/badge/Version-0.1.0-orange)](https://github.com/Moses-main/ai-agent-toolkit)

---

## ✨ Why This Framework?

- **🔌 Plug & Play** - Swap LLM providers without changing your agent logic
- **🧠 Memory Built-in** - Multiple memory strategies for different use cases
- **🔧 Tools Made Easy** - Decorator-based tool creation
- **🧪 Production Ready** - Error handling, retries, streaming, logging
- **📦 Minimal Dependencies** - No heavy frameworks

---

## 🚀 Quick Start

### Option 1: Clone & Install (Recommended)

```bash
# Clone the repository
git clone https://github.com/Moses-main/ai-agent-toolkit.git
cd ai-agent-toolkit

# Install dependencies
pip install -r requirements.txt

# Install in development mode
pip install -e .
```

### Option 2: Create from Templates

```bash
# Clone
git clone https://github.com/Moses-main/ai-agent-toolkit.git
cd ai-agent-toolkit

# Run a template directly
python templates/simple/agent.py
python templates/tool_agent/agent.py
python templates/conversational/agent.py
python templates/react/agent.py
```

### Create Your First Agent

```python
# Create your agent
from ai_agent import Agent, OpenAIClient

# Initialize LLM client
client = OpenAIClient(api_key="your-api-key")

# Create agent with tools
agent = Agent(
    client=client,
    tools=[calculator, search, your_custom_tool]
)

# Run!
response = agent.run("What's the weather in Lagos and calculate 25 * 4?")
print(response)
```

---

## 🏗️ Architecture

```
ai-agent-toolkit/
├── ai_agent/           # Core framework
│   ├── agent.py       # Agent implementations
│   ├── client.py      # LLM clients (OpenAI, Anthropic, Ollama)
│   ├── memory.py      # Memory strategies
│   ├── tools/        # Tool system
│   └── exceptions.py # Error classes
├── templates/        # Agent templates
├── examples/         # Usage examples
└── tests/           # Test suite
```

---

## 💡 Quick Examples

### Basic Agent

```python
from ai_agent import Agent, OpenAIClient
from ai_agent.tools import calculator

agent = Agent(
    client=OpenAIClient(api_key="your-key"),
    tools=[calculator]
)

result = agent.run("What is 100 + 200?")
```

### Custom Tools

```python
from ai_agent.tools import tool

@tool(name="fetch_url", description="Fetch content from a URL")
def fetch_url(url: str) -> str:
    """Fetch content from a URL."""
    import requests
    return requests.get(url).text[:500]

# Add to agent
agent = Agent(client=client, tools=[fetch_url])
```

### Memory

```python
from ai_agent import Agent
from ai_agent.memory import ConversationBufferMemory

# With conversation history
memory = ConversationBufferMemory()
agent = Agent(client=client, memory=memory)

agent.run("My name is Moses")
agent.run("What's my name?")  # Remembers!
```

---

## 🛠️ Building Your Own Agent

### Step 1: Choose Your LLM Client

```python
# OpenAI
from ai_agent.clients import OpenAIClient
client = OpenAIClient(api_key="sk-...")

# Anthropic (Claude)
from ai_agent.clients import AnthropicClient  
client = AnthropicClient(api_key="sk-ant-...")

# Local (Ollama)
from ai_agent.clients import OllamaClient
client = OllamaClient(model="llama2")
```

### Step 2: Create Tools

```python
from ai_agent.tools import tool

@tool(name="your_tool", description="What your tool does")
def your_tool(param1: str, param2: int = 10) -> str:
    """Tool implementation."""
    return f"Result: {param1}, {param2}"
```

### Step 3: Add Memory (Optional)

```python
from ai_agent.memory import (
    ConversationBufferMemory,  # Store all
    SummarizerMemory,          # Summarize old messages
    TokenMemory,               # Limit by tokens
)
```

### Step 4: Configure & Run

```python
agent = Agent(
    client=client,
    model="gpt-4",
    tools=[tool1, tool2],
    memory=memory,
    system_prompt="You are a helpful...",
    temperature=0.7,
)

response = agent.run("Your query here")
```

---

## 📋 Available Features

| Feature | Description |
|---------|-------------|
| **Tool Calling** | Automatic function execution |
| **ReAct Agent** | Reasoning + Acting loop |
| **Streaming** | Real-time token responses |
| **Retry Logic** | Built-in error handling |
| **Observability** | Detailed logging |
| **Multi-client** | OpenAI, Anthropic, Ollama |

---

## 🤖 Agent Templates

### 1. Simple Chat Agent

```python
# Best for: Basic Q&A, simple tasks
agent = Agent(
    client=client,
    system_prompt="You are a helpful assistant."
)
```

### 2. Tool-using Agent

```python
# Best for: Tasks requiring external actions
agent = Agent(
    client=client,
    tools=[calculator, search, fetch_url]
)
```

### 3. Conversational Agent

```python
# Best for: Chatbots, customer support
from ai_agent.memory import ConversationBufferMemory

agent = Agent(
    client=client,
    memory=ConversationBufferMemory()
)
```

### 4. ReAct Agent

```python
# Best for: Complex reasoning, math, multi-step tasks
from ai_agent import ReActAgent

agent = ReActAgent(
    client=client,
    max_iterations=10,
    tools=[calculator]
)
```

---

## 🔌 Supported LLM Providers

| Provider | Model | Status |
|----------|-------|--------|
| OpenAI | gpt-4, gpt-3.5-turbo | ✅ |
| Anthropic | claude-3-opus, claude-3-sonnet | ✅ |
| Ollama | llama2, mistral, etc. | ✅ |
| Azure OpenAI | gpt-4, gpt-3.5-turbo | ✅ |

---

## 🧪 Testing

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/test_agent.py

# With coverage
pytest --cov=ai_agent tests/
```

---

## 🤝 Contributing

1. Fork the repo
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a PR

See [CONTRIBUTING.md](CONTRIBUTING.md) for details.

---

## 📝 License

MIT License - See [LICENSE](LICENSE)

---

## 🔗 Resources

- [LangChain Docs](https://python.langchain.com)
- [OpenAI API](https://platform.openai.com)
- [Anthropic Docs](https://docs.anthropic.com)
- [Ollama](https://ollama.ai)

---

<p align="center">
  <strong>⭐ Star if useful!</strong>
</p>
